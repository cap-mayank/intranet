  August 24, 2012
                                  Apache Haus Distribution
                        
  Application:       mod_authnz_sspi 0.1.0-a1 for Apache 2.4.x x86
  Distribution File: mod_authnz_sspi-0.1.0a1-2.4.x-x86.zip
 
  Author: Ennio Zarlenga for mod_authnz_sspi
          Tim Costello for the original mod_auth_sspi
  Original Home: http://sourceforge.net/projects/mod-auth-sspi/

  Win32 binary by: Gregg
  Mail: info@apachehaus.com
  Home: http://www.apachehaus.com


  authnz_sspi module for Apache 2.4 x86

  See doc/my_cfg.txt file for a sample config that worked for me on 
  Windows Vista using basic style auth.

  NOTE: Windows XP and possibly Server 2003 users, This module will 
  not work unless Apache is running as a service under the SYSTEM
  user (which is the default). Running Apache from the command line
  or as a service running under under a user other than SYSTEM will
  result in this module letting anyone in, regardless of username/
  password. 



